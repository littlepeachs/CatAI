"""Generate donut charts for metal distribution and heterogeneous support distribution."""

import json
from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib

matplotlib.rcParams['font.family'] = 'Arial'

# ---------------------------------------------------------------------------
# Load data
# ---------------------------------------------------------------------------
DATA_PATH = Path("analysis_results/coupling_info_results.json")
OUTPUT_PATH = Path("analysis_results/metal_support_donut.png")

with open(DATA_PATH, "r", encoding="utf-8") as f:
    data = json.load(f)

# ---------------------------------------------------------------------------
# Count metals (all records) and supports (heterogeneous only)
# ---------------------------------------------------------------------------
metal_counter: Counter = Counter()
support_counter: Counter = Counter()

for rec in data:
    metals = (rec.get("metal") or "").split("/")
    for m in metals:
        m = m.strip()
        if m and m.lower() != "none":
            metal_counter[m] += 1
    if rec.get("catalysis_type") == "heterogeneous":
        s = rec.get("support") or "Others"
        if s.lower() == "none":
            s = "Others"
        support_counter[s] += 1

# ---------------------------------------------------------------------------
# Prepare metal data: top 6 + Others
# ---------------------------------------------------------------------------
TOP_N_METALS = 6
metal_items = metal_counter.most_common()
top_metals = metal_items[:TOP_N_METALS]
others_count = sum(v for _, v in metal_items[TOP_N_METALS:])
metal_labels = [k for k, _ in top_metals] + ["Others"]
metal_values = [v for _, v in top_metals] + [others_count]

# ---------------------------------------------------------------------------
# Prepare support data (fixed order)
# ---------------------------------------------------------------------------
SUPPORT_ORDER = ["Metal Oxides", "Carbon", "Nitride", "Metals", "Others"]
support_labels = SUPPORT_ORDER
support_values = [support_counter.get(s, 0) for s in SUPPORT_ORDER]

# ---------------------------------------------------------------------------
# Color palettes
# ---------------------------------------------------------------------------
# Metal: blue-grey gradient
metal_colors = [
    "#b0c4de",  # Pd - light steel blue
    "#4682b4",  # Ni - steel blue
    "#6495ed",  # Cu - cornflower blue
    "#d4e4f7",  # Au - very light blue
    "#87a8c9",  # Fe
    "#a4c2a5",  # Ru - muted green
    "#c8d8e8",  # Others - pale
]

# Support: blue-green gradient
support_colors = [
    "#b0c4de",  # Metal Oxides
    "#6495ed",  # Carbon
    "#4682b4",  # Nitride
    "#a4c2a5",  # Metals
    "#d4e4f7",  # Others
]

# ---------------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------------
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

# --- Left: Metal donut ---
wedges1, texts1, autotexts1 = ax1.pie(
    metal_values,
    labels=metal_labels,
    colors=metal_colors[:len(metal_labels)],
    autopct=lambda pct: f"{pct:.1f}%" if pct >= 3 else "",
    startangle=90,
    pctdistance=0.78,
    wedgeprops=dict(width=0.42, edgecolor="white", linewidth=1.5),
    textprops=dict(fontsize=11),
)
for at in autotexts1:
    at.set_fontsize(10)
    at.set_color("#333333")
ax1.text(0, 0, "Metal", ha="center", va="center", fontsize=16, fontweight="bold", color="#333333")
ax1.set_title(f"Metal Distribution (n={sum(metal_values)})", fontsize=13, pad=12)

# --- Right: Support donut ---
wedges2, texts2, autotexts2 = ax2.pie(
    support_values,
    labels=support_labels,
    colors=support_colors[:len(support_labels)],
    autopct=lambda pct: f"{pct:.1f}%" if pct >= 3 else "",
    startangle=90,
    pctdistance=0.78,
    wedgeprops=dict(width=0.42, edgecolor="white", linewidth=1.5),
    textprops=dict(fontsize=11),
)
for at in autotexts2:
    at.set_fontsize(10)
    at.set_color("#333333")
ax2.text(0, 0, "Support", ha="center", va="center", fontsize=16, fontweight="bold", color="#333333")
ax2.set_title(f"Heterogeneous Support (n={sum(support_values)})", fontsize=13, pad=12)

plt.tight_layout()
plt.savefig(OUTPUT_PATH, dpi=200, bbox_inches="tight", facecolor="white")
plt.close()
print(f"Saved to {OUTPUT_PATH}")
